public class msFrameTest{
    public static void main(String[]args){
        new mineSweeperFrame();
    }
}