import java.util.*;
public class gridlayout{
    int gridArray[][]=new int[10][10];
    char[][] charArray = new char[10][10];
    public gridlayout(){
    }
    public int[][] getgrid(){
        int gridArray[][]=new int[10][10];
        //int min= 5;
        //int max=10;
        //int numFlags=Math.random()*(max-min)+min;
        for(int row=0;row<10;row++){
            for(int col=0;col<10;col++){
                double random= Math.random()*100;
                int randomint= (int)random;
                while(randomint>8){
                    random= Math.random()*100;
                    randomint= (int)random; 
                }
                gridArray[row][col]= randomint;
                //0 means bomb for now
            } 
        }    //flag or no flag test get random num between 0 and 2 if zero put bom
        //for(int i=0; i<gridArray.length;i++){
            //System.out.println(Arrays.toString(gridArray[i]));
        //}
        //time to make gridwnumbers
        // make all zeros -1's so we done get confused
        for(int row=0;row<10;row++){
            for(int col=0;col<10;col++){
                if(gridArray[row][col]==0){
                    gridArray[row][col]=-1;
                }
            }
        }



        for(int row=0;row<10;row++){
            for(int col=0;col<10;col++){
                int bombcount=0;
                if(gridArray[row][col]==-1){
                    gridArray[row][col]=-1;
                }
                else{
                    if(row==0||row==9||col==0||col==9){
                        //special cases
                        if(row==0){
                            if(col==0){
                                //if row is 0 AND col 0 (corner)
                                bombcount=0;
                                for(int i=row;i<row+2;i++){
                                    for(int j=col;j<col+2;j++){
                                        if(gridArray[i][j]==-1){
                                        bombcount+=1;
                                        }
                                    }   
                                }   
                            }
                            if(col==9){
                                // if row 0 AND col 9 (corner)
                                bombcount=0;
                                for(int i=row;i<row+2;i++){
                                    for(int j=col-1;j<=col;j++){
                            
                                        if(gridArray[i][j]==-1){
                                        bombcount+=1;
                                        }
                                    }
                                }   
                            }
                            if(col!=0 && col!=9){
                            //if row = 0 but no other special
                                bombcount=0;
                                for(int i=row;i<row+2;i++){
                                    for(int j=col-1;j<col+2;j++){
                                        if(gridArray[i][j]==-1){
                                        bombcount+=1;
                                        }
                                    }
                                }
                            }
                        }
                        if(row==9){
                            if(col==0){
                                //if row 9 AND col 0 (corner)
                                bombcount=0;
                                for(int i=row-1;i<=row;i++){
                                    for(int j=col;j<col+2;j++){
                                        if(gridArray[i][j]==-1){
                                        bombcount+=1;
                                        }
                                    }
                                }
                            }
                            if(col==9){
                                //if row is 9 AND col is 9 (corner)
                                bombcount=0;
                                for(int i=row-1;i<=row;i++){
                                    for(int j=col-1;j<col;j++){
                                        if(gridArray[i][j]==-1){
                                            bombcount+=1;
                                        }
                                    }
                                }
                            }
                            if(col!=0 && col!=9){
                            //if row=9 but no other special
                            bombcount=0;
                                for(int i=row-1;i<=row;i++){
                                    for(int j=col-1;j<col+2;j++){
                                        if(gridArray[i][j]==-1){
                                            bombcount+=1;
                                        }
                        
                                    }
                                }
                            }
                        }
                        if(col==0 && row!=0 && row!=9){
                            bombcount=0;
                            for(int i=row-1;i<row+2;i++){
                                for(int j=col;j<col+2;j++){
                                    if(gridArray[i][j]==-1){
                                        bombcount+=1;
                                    }
                                }
                            }                        
                        }
                        if(col==9 && row!=0 && row!=9){
                            bombcount=0;
                            for(int i=row-1;i<row+2;i++){
                                for(int j=col-1;j<col;j++){
                                    if(gridArray[i][j]==-1){
                                        bombcount+=1;
                                    }
                                }
                            }
                        }
                        gridArray[row][col]=bombcount;
                    }

                    else{
                        bombcount=0;
                        for(int i=row-1;i<row+2;i++){
                            for(int j=col-1;j<col+2;j++){
                                if(gridArray[i][j]==-1){
                                    bombcount+=1;
                                }
                            }
                        }
                        gridArray[row][col]=bombcount;
                    }
                }
            }
        }
        System.out.println("this should be the new array lol");
        for(int i=0; i<gridArray.length;i++){
            System.out.println(Arrays.toString(gridArray[i]));
        }
        this.gridArray=gridArray;
        return gridArray;
    }

    public char[][] getCharGrid(){
        char[][] charArray = new char[10][10];
        for(int row=0;row<10;row++){
            for(int col=0;col<10;col++){
                charArray[row][col]='?';
            }
        }
        for(int i=0; i<charArray.length;i++){
            System.out.println(Arrays.toString(charArray[i]));
        }
        this.charArray=charArray;
        return charArray;
    }

    public void clickSquare(){
        //int 1 row, int 2 col
        Scanner scan = new Scanner(System.in);
        System.out.println("pick index");
        int num1=scan.nextInt();
        int num2=scan.nextInt();
        if(gridArray[num1][num2]==-1){
            System.out.println("You Lose");
        }
        else{
        int num= gridArray[num1][num2];
        // i know this is a bad way to do it i cant figure out the nie way to do it rn
        char value='0';
        if(num==1){
            value='1';
        }
        if(num==2){
            value='2';
        }
        if(num==3){
            value='3';
        }
        charArray[num1][num2]=value;
        }
        
    
    }
    public char[][] flagSquare(){
        //int 1 row, int 2 col
        Scanner scan = new Scanner(System.in);
        System.out.println("pick index");
        int num1=scan.nextInt();
        int num2=scan.nextInt();
        charArray[num1][num2]= 'F';
        return charArray;
        
    }
    public void printboard(){
    for(int i=0; i<charArray.length;i++){
        System.out.println(Arrays.toString(charArray[i]));
    }

}

    /* ok once we have our grid representing how many flags each surround block has, we need a character
    array with question marks everywhere then we figugre out how to interect with player but just with
    console for now.
    somehow need to be able to interact with character array

    player chooses square. player has 2 choices. player has 4 outcomes. 
    1. uncover nonbom
    2. uncover bomb. lose
    3. flag square correctly
    4. flag square incorrectly

    i need a way to represent these four outcomes and a way for the player to choose the 2 choices
    so far I have a board for where bombs are
    a board that the player sees that is a character board
    a board that represesnts what is "under" the board the player sees (what are bombs vs how many bombs
    surround a square)
    for now I dont necessarily need a board that represents the four outcomes
    Question: how do I make sure all representative boards are representing the main board (bomb v no bomb)?
    do I make my final grid in getgrid() a global var? bc that one will have bombs vs how many bombs
    surround a square

    **/




        

            
}
