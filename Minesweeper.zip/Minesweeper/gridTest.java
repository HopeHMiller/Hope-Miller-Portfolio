public class gridTest{
    
    public static  void main(String[]args){
        gridlayout newGrid = new gridlayout();
        newGrid.getgrid();
        newGrid.getCharGrid();
        newGrid.clickSquare();
        newGrid.printboard();
        newGrid.flagSquare();
        newGrid.printboard();
        System.out.println("click a bomb so u can check the u lose");
        newGrid.clickSquare();
        newGrid.printboard();

        }
    }
