import javax.swing.*;
import java.awt.*;
public class MineSweeper extends JFrame{
    mineSweeperFrame(){
    setTitle("Mine Sweeper");
    Toolkit kit =Toolkit.getDefaultToolkit();
    setSize(700,700);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JPanel panel = new mineSweeperPanel();
    add(panel);
    setVisible(true);
    }
}