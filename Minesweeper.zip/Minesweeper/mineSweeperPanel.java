import javax.swing.*;
import javax.swing.plaf.basic.BasicOptionPaneUI.ButtonActionListener;

import java.awt.*;
import java.awt.event.*;
public class mineSweeperPanel extends JPanel{
    int row;
    int col;
    gridlayout Grid = new gridlayout();
    int[][] board=Grid.getgrid();
    JButton[][] buttonGrid = new JButton[10][10];
    public mineSweeperPanel(){
        setLayout(new GridLayout(10,0));
        for(int row=0;row<10;row++){
            for(int col=0;col<10;col++){
                this.row=row;
                this.col=col;
                int matchingnum=board[row][col];
                String num =String.valueOf(matchingnum);
                buttonGrid[row][col]= new JButton("?");
                JButton name1 = buttonGrid[row][col];
                add(buttonGrid[row][col]);
                buttonGrid[row][col].addMouseListener(new MouseAdapter(){
                    public void mouseClicked(MouseEvent e){
                        if(SwingUtilities.isRightMouseButton(e)){
                            name1.setText("F");
                            name1.setBackground(Color.PINK);
                            name1.setOpaque(true);
                        }
                        else{
                            if (matchingnum==-1){
                                name1.setText("FAIL");
                                //end game
                                name1.setBackground(Color.RED);
                                name1.setOpaque(true);
                                
                            }
                            else{
                                name1.setText(num);
                                name1.setBackground(Color.CYAN);
                                name1.setOpaque(false);
                            }
                        
                        }

                    }
                });
            }
        }
        
        }
            
        
        /*
        setLayout(new GridLayout(10,0));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        add (new JButton("?"));
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?")); 
        add (new JButton("?"));
        **/

    }
